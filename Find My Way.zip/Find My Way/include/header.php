<!-- escribir html:5 sale solo el codigo-->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD PHP</title> 
<!--Copiamos los estilos de Bootstrap-->

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>
<!-- creamos este Nav para la barra de navegación --> 
<nav class="navbar navbar-dark bg-dark"> 
    


<a href="inicio_admin.php" class="navbar-brand"> Volver </a> 

<div class= "container"> 
  
  
        <a  class="navbar-brand"> Listado de reclamos o quejas </a>
        
    </div> 
     
</nav>    