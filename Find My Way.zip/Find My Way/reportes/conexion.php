<?php


$mysqli = new mysqli("localhost", "root", "", "login_admin_db");
