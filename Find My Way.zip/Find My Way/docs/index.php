<!DOCTYPE html>
<html>
  <head>
    <title>Find My Way</title>
    <meta charset="utf-8">
    <link rel="icon" href="imagenes/icon.png">
    

    <link rel="stylesheet" type="text/css" href="estilo.css"> 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  </head>

  <body>

    

        <img src="imagenes/icon.png"width="60" height="60px">

        <div class="Titulo_find">
          <h1> Find My Way</h1>
        </div>

        <div class="conten">

        <ul>
          
          
          <li> <a href="../loginadmin.php">Cliente</a> </li>
          <li> <a href="../login_nosotros.php">Administrador</a> </li>
          <li> <a href="../planes/planes.php">Comprar Find My Way</a></li>
        
      </ul>
      
      

      

      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>

        <div class="texto_inicio">

       <p align="center">
        Find My Way es una aplicación movil, la cual tiene por objetivo informar y ayudar a las personas de los sectores de 
        Talcahuano:Perales, San Marcos, Cruz del sur y salinas con el fin de dar a conocer los diferentes horarios y rutas de 
        los buses, así como también ayudar a organizarse mejor en sus tiempos y aumentar la seguridad de las personas, 
        quienes no tendrán que esperar mas tiempo del necesario.
       </p>
      </div>
    
  </div>
  

  </body>



  </html>